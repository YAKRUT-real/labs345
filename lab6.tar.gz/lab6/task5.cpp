#include <iostream>
#include <cstring>
#include <cmath>

using namespace std;

// Рекурсивное построение треугольника Серпинского
void sierpinski(int n, int x, int y, int size, char** grid) {
    if (n == 0) {
        // Базовый случай: закрашиваем треугольник
        for (int i = 0; i < size; i++) {
            for (int j = 0; j <= i; j++) {
                grid[y + i][x + j] = '*';
                grid[y + i][x - j] = '*';
            }
        }
        return;
    }

    int newSize = size / 2;
    // Верхний треугольник
    sierpinski(n - 1, x, y, newSize, grid);
    // Левый нижний
    sierpinski(n - 1, x - newSize, y + newSize, newSize, grid);
    // Правый нижний
    sierpinski(n - 1, x + newSize, y + newSize, newSize, grid);
}

int main() {
    int level;
    cout << "Введите глубину рекурсии (0-6): ";
    cin >> level;

    int size = pow(2, level);
    int height = size;
    int width = size * 2;

    // Создаём сетку
    char** grid = new char*[height];
    for (int i = 0; i < height; i++) {
        grid[i] = new char[width];
        memset(grid[i], ' ', width);
    }

    // Рисуем фрактал
    sierpinski(level, size - 1, 0, size, grid);

    // Выводим результат
    for (int i = 0; i < height; i++) {
        for (int j = 0; j < width; j++) {
            cout << grid[i][j];
        }
        cout << endl;
    }

    // Чистим память
    for (int i = 0; i < height; i++) {
        delete[] grid[i];
    }
    delete[] grid;

    return 0;
}
