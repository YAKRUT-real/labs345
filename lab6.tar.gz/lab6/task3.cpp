#include <iostream>
#include <iomanip>
#include <cmath>

using namespace std;

int main() {
    double A[4][4] = {
        {1.25, -0.04, 0.21, -1.16},
        {0.25, -1.23, -1.14, -0.09},
        {-0.21, -1.14, 0.8, -0.13},
        {0.15, -1.31, 0.06, -1.09}
    };

    double b[4] = {-1.24, -1.09, 2.56, 1.25};
    double L[4][4] = {0};
    double U[4][4] = {0};
    for (int i = 0; i < 4; i++) {
        L[i][i] = 1.0;
    }

    cout << "\nИсходная матрица A:" << endl;
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {
            cout << setw(10) << A[i][j] << " ";
        }
        cout << "| " << b[i] << endl;
    }
    for (int i = 0; i < 4; i++) {
        for (int j = i; j < 4; j++) {
            double sum = 0;
            for (int k = 0; k < i; k++) {
                sum += L[i][k] * U[k][j];
            }
            U[i][j] = A[i][j] - sum;
        }
        for (int j = i + 1; j < 4; j++) {
            double sum = 0;
            for (int k = 0; k < i; k++) {
                sum += L[j][k] * U[k][i];
            }
            L[j][i] = (A[j][i] - sum) / U[i][i];
        }
    }

    cout << "\nМатрица L:" << endl;
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {
            cout << setw(10) << L[i][j] << " ";
        }
        cout << endl;
    }

    cout << "\nМатрица U:" << endl;
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {
            cout << setw(10) << U[i][j] << " ";
        }
        cout << endl;
    }

    cout << "\nПроверка: L * U:" << endl;
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {
            double sum = 0;
            for (int k = 0; k < 4; k++) {
                sum += L[i][k] * U[k][j];
            }
            cout << setw(10) << sum << " ";
        }
        cout << endl;
    }
    double det = 1.0;
    for (int i = 0; i < 4; i++) {
        det *= U[i][i];
    }
    cout << "\nОпределитель матрицы A:" << det << endl;
    double y[4];
    for (int i = 0; i < 4; i++) {
        double sum = 0;
        for (int j = 0; j < i; j++) {
            sum += L[i][j] * y[j];
        }
        y[i] = b[i] - sum;
    }
    cout << "\nПрямой ход (L*y = b):" << endl;
    for (int i = 0; i < 4; i++) {
        cout << "y[" << i+1 << "] = " << y[i] << endl;
    }
    double x[4];
    for (int i = 3; i >= 0; i--) {
        double sum = 0;
        for (int j = i + 1; j < 4; j++) {
            sum += U[i][j] * x[j];
        }
        x[i] = (y[i] - sum) / U[i][i];
    }

    cout << "\nОбратный ход (U*x = y):" << endl;
    for (int i = 0; i < 4; i++) {
        cout << "x[" << i+1 << "] = " << x[i] << endl;
    }
    cout << "\nПроверка решения A*x = b:" << endl;
    for (int i = 0; i < 4; i++) {
        double sum = 0;
        for (int j = 0; j < 4; j++) {
            sum += A[i][j] * x[j];
        }
        cout << "Строка " << i+1 << ": " << sum << " (должно быть " << b[i] << ")" << endl;
    }
    cout << "x1 = " << x[0] << endl;
    cout << "x2 = " << x[1] << endl;
    cout << "x3 = " << x[2] << endl;
    cout << "x4 = " << x[3] << endl;

    return 0;
}
