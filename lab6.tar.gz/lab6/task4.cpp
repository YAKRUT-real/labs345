#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
using namespace std;

const int MAX = 1e9;

int n, m;
vector<vector<int>> a;

void printBoard(vector<vector<int>>& board) {
    for (int i = 0; i < board.size(); i++) {
        for (int j = 0; j < board[i].size(); j++) {
            cout << board[i][j] << " ";
        }
        cout << endl;
    }
    cout << endl;
}

int soluf(int border_value) {
    vector<vector<int>> target(n, vector<int>(m));
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            if (i == 0 || i == n-1 || j == 0 || j == m-1) {
                target[i][j] = border_value;
            } else {
                target[i][j] = 1 - border_value;
            }
        }
    }
    vector<pair<int, int>> T;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            if (a[i][j] != target[i][j]) {
                T.push_back({i, j});
            }
        }
    }
    if (T.empty()) return 0;
    if ((int)T.size() % 2 != 0) {
        return MAX;
    }
    int k = T.size();
    vector<int> dp(1 << k, MAX);
    dp[0] = 0;
    for (int mask = 0; mask < (1 << k); mask++) {
        if (dp[mask] == MAX) continue;
        int first = -1;
        for (int i = 0; i < k; i++) {
            if (!(mask & (1 << i))) {
                first = i;
                break;
            }
        }
        if (first == -1) continue;
        for (int j = first + 1; j < k; j++) {
            if (!(mask & (1 << j))) {
                int new_mask = mask | (1 << first) | (1 << j);
                int dist = abs(T[first].first - T[j].first) + abs(T[first].second - T[j].second);
                dp[new_mask] = min(dp[new_mask], dp[mask] + dist);
            }
        }
    }

    return dp[(1 << k) - 1];
}

int main() {
    cin >> n >> m;
    a.resize(n, vector<int>(m));
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            cin >> a[i][j];
        }
    }
    int ans1 = soluf(0);
    int ans2 = soluf(1);
    int ans = min(ans1, ans2);
    if (ans >= MAX) {
        cout << -1 << endl;
    } else {
        cout << ans << endl;
    }
    return 0;
}
