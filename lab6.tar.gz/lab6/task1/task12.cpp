#include <iostream>
#include <vector>
#include <random>
#include <algorithm>

using namespace std;
bool hasBadDigits(int num) {
    if (num == 0) return false;
    int n = abs(num);
    while (n > 0) {
        int digit = n % 10;
        if (digit == 3 || digit == 5 || digit == 7) {
            return true;
        }
        n /= 10;
    }
    return false;
}
bool isGood(int num) {
    return !hasBadDigits(num);
}

int main() {
    const int M = 5;
    const int N = 10;
    const int MIN_VAL = 1000;
    const int MAX_VAL = 3000;

    random_device rd;
    mt19937 gen(rd());
    uniform_int_distribution<> dist(MIN_VAL, MAX_VAL);

    vector<vector<int>> matrix(M, vector<int>(N));
    for (int i = 0; i < M; ++i) {
        for (int j = 0; j < N; ++j) {
            matrix[i][j] = dist(gen);
        }
    }
    cout << "Матрица:\n";
    for (const auto& row : matrix) {
        for (int val : row) {
            cout << val << " ";
        }
        cout << '\n';
    }

    int bestRow = -1;
    int bestLen = 0;
    vector<int> bestSequence;
    for (int i = 0; i < M; ++i) {
        int currentLen = 0;
        int maxLenInRow = 0;
        int startIdx = 0;
        int bestStart = 0;

        for (int j = 0; j < N; ++j) {
            if (isGood(matrix[i][j])) {
                if (currentLen == 0) startIdx = j;
                currentLen++;
                if (currentLen > maxLenInRow) {
                    maxLenInRow = currentLen;
                    bestStart = startIdx;
                }
            } else {
                currentLen = 0;
            }
        }

        cout << "Строка " << i+1 << ", макс. длина: " << maxLenInRow << '\n';

        if (maxLenInRow > bestLen) {
            bestLen = maxLenInRow;
            bestRow = i;
            bestSequence.clear();
            for (int j = bestStart; j < bestStart + bestLen; ++j) {
                bestSequence.push_back(matrix[i][j]);
            }
        }
    }

    cout << "\nНомер строки с самой длинной последовательностью: " << bestRow+1 << '\n';
    cout << "Длина последовательности: " << bestLen << '\n';
    cout << "Последовательность: ";
    for (int val : bestSequence) {
        cout << val << " ";
    }
    cout << '\n';

    return 0;
}
