#include <iostream>
#include <vector>
#include <random>
#include <iomanip>

using namespace std;

int main() {
    const int N = 8;
    const int MIN_VAL = 100;
    const int MAX_VAL = 200;

    random_device rd;
    mt19937 gen(rd());
    uniform_int_distribution<> dist(MIN_VAL, MAX_VAL);
    vector<vector<int>> matrix(N, vector<int>(N));
    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < N; ++j) {
            matrix[i][j] = dist(gen);
        }
    }
    cout << "Исходная матрица:\n";
    for (const auto& row : matrix) {
        for (int val : row) {
            cout << setw(5) << val;
        }
        cout << '\n';
    }
    vector<int> rowSums(N, 0);
    int maxRowSum = -1;
    int maxRowIdx = 0;

    cout << "\nСуммы строк:\n";
    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < N; ++j) {
            rowSums[i] += matrix[i][j];
        }
        cout << "Строка " << i+1 << ": " << rowSums[i] << '\n';
        if (rowSums[i] > maxRowSum) {
            maxRowSum = rowSums[i];
            maxRowIdx = i;
        }
    }
    vector<int> colSums(N, 0);
    int minColSum = 1e9;
    int minColIdx = 0;

    cout << "\nСуммы столбцов:\n";
    for (int j = 0; j < N; ++j) {
        for (int i = 0; i < N; ++i) {
            colSums[j] += matrix[i][j];
        }
        cout << "Столбец " << j+1 << ": " << colSums[j] << '\n';
        if (colSums[j] < minColSum) {
            minColSum = colSums[j];
            minColIdx = j;
        }
    }

    cout << "\nНомер строки с максимальной суммой: " << maxRowIdx+1 << "\n";
    cout << "Номер столбца с минимальной суммой: " << minColIdx+1 << "\n";
    matrix[maxRowIdx][minColIdx] = 0;
    cout << "\nМатрица после замены:\n";
    for (const auto& row : matrix) {
        for (int val : row) {
            cout << setw(5) << val;
        }
        cout << '\n';
    }

    return 0;
}
