#include <iostream>
#include <vector>
#include <random>
#include <chrono>
#include <thread>
#include <cstdlib>
#define CLEAR "clear"
using namespace std;

const int SIZE = 60;
const int GENERATIONS = 200;
const int DELAY_MS = 60;

using Grid = vector<vector<bool>>;

Grid randomGrid() {
    Grid grid(SIZE, vector<bool>(SIZE, false));
    random_device rd;
    mt19937 gen(rd());
    uniform_int_distribution<> dist(0, 3);

    for (int i = 0; i < SIZE; ++i) {
        for (int j = 0; j < SIZE; ++j) {
            grid[i][j] = (dist(gen) == 0);
        }
    }
    return grid;
}

Grid parasiteGrid() {
    Grid grid(SIZE, vector<bool>(SIZE, false));
    int r = 10, c = 10;
    grid[r][c+1] = true;
    grid[r][c+2] = true;
    grid[r+1][c] = true;
    grid[r+1][c+1] = true;
    grid[r+2][c+1] = true;

    return grid;
}

int neighbors(const Grid& g, int x, int y) {
    int cnt = 0;
    for (int dx = -1; dx <= 1; ++dx) {
        for (int dy = -1; dy <= 1; ++dy) {
            if (dx != 0 || dy != 0) {
                int nx = (x + dx + SIZE) % SIZE;
                int ny = (y + dy + SIZE) % SIZE;
                if (g[nx][ny]) cnt++;
            }
        }
    }
    return cnt;
}

Grid nextGen(const Grid& cur) {
    Grid nxt(SIZE, vector<bool>(SIZE, false));
    for (int i = 0; i < SIZE; ++i) {
        for (int j = 0; j < SIZE; ++j) {
            int nb = neighbors(cur, i, j);
            if (cur[i][j])
                nxt[i][j] = (nb == 2 || nb == 3);
            else
                nxt[i][j] = (nb == 3);
        }
    }
    return nxt;
}

void printGrid(const Grid& g, int gen) {
    system(CLEAR);
    cout << "Поколение " << gen << "\n";
    cout << "+" << string(SIZE, '-') << "+\n";

    int alive = 0;
    for (int i = 0; i < SIZE; ++i) {
        cout << "|";
        for (int j = 0; j < SIZE; ++j) {
            if (g[i][j]) {
                cout << '0';
                alive++;
            } else {
                cout << ' ';
            }
        }
        cout << "|\n";
    }
    cout << "+" << string(SIZE, '-') << "+\n";
    cout << "Живых клеток: " << alive << "\n";
}

int main() {
    int mode;
    cout << "1. Сорняк (разрастание и дублирование)\n";
    cout << "2. Случайное поле\n";
    cout << ">>> ";
    if (!(cin >> mode)) return 1;

    Grid g = (mode == 1) ? parasiteGrid() : randomGrid();

    for (int gen = 0; gen <= GENERATIONS; ++gen) {
        printGrid(g, gen);
        g = nextGen(g);
        this_thread::sleep_for(chrono::milliseconds(DELAY_MS));
    }

    return 0;
}
