#include <iostream>
#include <vector>
#include <string>
#include <random>
#include <cstring>
#include <fstream>

using namespace std;

const unsigned char sbox[256] = {
    0x63, 0x7c, 0x77, 0x7b, 0xf2, 0x6b, 0x6f, 0xc5, 0x30, 0x01, 0x67, 0x2b, 0xfe, 0xd7, 0xab, 0x76,
    0xca, 0x82, 0xc9, 0x7d, 0xfa, 0x59, 0x47, 0xf0, 0xad, 0xd4, 0xa2, 0xaf, 0x9c, 0xa4, 0x72, 0xc0,
    0xb7, 0xfd, 0x93, 0x26, 0x36, 0x3f, 0xf7, 0xcc, 0x34, 0xa5, 0xe5, 0xf1, 0x71, 0xd8, 0x31, 0x15,
    0x04, 0xc7, 0x23, 0xc3, 0x18, 0x96, 0x05, 0x9a, 0x07, 0x12, 0x80, 0xe2, 0xeb, 0x27, 0xb2, 0x75,
    0x09, 0x83, 0x2c, 0x1a, 0x1b, 0x6e, 0x5a, 0xa0, 0x52, 0x3b, 0xd6, 0xb3, 0x29, 0xe3, 0x2f, 0x84,
    0x53, 0xd1, 0x00, 0xed, 0x20, 0xfc, 0xb1, 0x5b, 0x6a, 0xcb, 0xbe, 0x39, 0x4a, 0x4c, 0x58, 0xcf,
    0xd0, 0xef, 0xaa, 0xfb, 0x43, 0x4d, 0x33, 0x85, 0x45, 0xf9, 0x02, 0x7f, 0x50, 0x3c, 0x9f, 0xa8,
    0x51, 0xa3, 0x40, 0x8f, 0x92, 0x9d, 0x38, 0xf5, 0xbc, 0xb6, 0xda, 0x21, 0x10, 0xff, 0xf3, 0xd2,
    0xcd, 0x0c, 0x13, 0xec, 0x5f, 0x97, 0x44, 0x17, 0xc4, 0xa7, 0x7e, 0x3d, 0x64, 0x5d, 0x19, 0x73,
    0x60, 0x81, 0x4f, 0xdc, 0x22, 0x2a, 0x90, 0x88, 0x46, 0xee, 0xb8, 0x14, 0xde, 0x5e, 0x0b, 0xdb,
    0xe0, 0x32, 0x3a, 0x0a, 0x49, 0x06, 0x24, 0x5c, 0xc2, 0xd3, 0xac, 0x62, 0x91, 0x95, 0xe4, 0x79,
    0xe7, 0xc8, 0x37, 0x6d, 0x8d, 0xd5, 0x4e, 0xa9, 0x6c, 0x56, 0xf4, 0xea, 0x65, 0x7a, 0xae, 0x08,
    0xba, 0x78, 0x25, 0x2e, 0x1c, 0xa6, 0xb4, 0xc6, 0xe8, 0xdd, 0x74, 0x1f, 0x4b, 0xbd, 0x8b, 0x8a,
    0x70, 0x3e, 0xb5, 0x66, 0x48, 0x03, 0xf6, 0x0e, 0x61, 0x35, 0x57, 0xb9, 0x86, 0xc1, 0x1d, 0x9e,
    0xe1, 0xf8, 0x98, 0x11, 0x69, 0xd9, 0x8e, 0x94, 0x9b, 0x1e, 0x87, 0xe9, 0xce, 0x55, 0x28, 0xdf,
    0x8c, 0xa1, 0x89, 0x0d, 0xbf, 0xe6, 0x42, 0x68, 0x41, 0x99, 0x2d, 0x0f, 0xb0, 0x54, 0xbb, 0x16
};

const unsigned int rcon[11] = {
    0x00000000, 0x01000000, 0x02000000, 0x04000000, 0x08000000,
    0x10000000, 0x20000000, 0x40000000, 0x80000000, 0x1B000000, 0x36000000
};

void BytesToMatrix(const unsigned char* input, unsigned int* state)
{
    for (unsigned int i = 0; i < 4; ++i)
    {
        state[i] = (input[i * 4 + 0] << 24) |
        (input[i * 4 + 1] << 16) |
        (input[i * 4 + 2] << 8)  |
        (input[i * 4 + 3]);
    }
}

void MatrixToBytes(const unsigned int* state, unsigned char* output)
{
    for (unsigned int i = 0; i < 4; ++i)
    {
        output[i * 4 + 0] = state[i] >> 24;
        output[i * 4 + 1] = state[i] >> 16;
        output[i * 4 + 2] = state[i] >> 8;
        output[i * 4 + 3] = state[i];
    }
}

unsigned char galois_multiply(unsigned char a, unsigned char b)
{
    unsigned char p = 0;
    for (int counter = 0; counter < 8; counter++)
    {
        if (b & 1) p ^= a;
        bool hi_bit_set = (a & 0x80);
        a <<= 1;
        if (hi_bit_set) a ^= 0x1B;
        b >>= 1;
    }
    return p;
}


void expand_key(const unsigned char* key, unsigned char* round_keys, int rounds)
{
    for (unsigned int i = 0; i < 16; ++i) round_keys[i] = key[i];
    int words_generated = 4;

    for (int round = 1; round <= rounds; ++round)
    {
        unsigned char temp[4];

        for (int i = 0; i < 4; ++i) temp[i] = round_keys[(words_generated - 1) * 4 + i];

        unsigned char t = temp[0];
        temp[0] = temp[1]; temp[1] = temp[2]; temp[2] = temp[3]; temp[3] = t;
        for (int i = 0; i < 4; ++i) temp[i] = sbox[temp[i]];
        temp[0] ^= (rcon[round] >> 24);


        for (int i = 0; i < 4; ++i)
        {
            round_keys[words_generated * 4 + i] = round_keys[(words_generated - 4) * 4 + i] ^ temp[i];
        }
        words_generated++;


        for (int w = 0; w < 3; ++w)
        {
            for (int i = 0; i < 4; ++i)
            {
                round_keys[words_generated * 4 + i] = round_keys[(words_generated - 4) * 4 + i] ^ round_keys[(words_generated - 1) * 4 + i];
            }
            words_generated++;
        }
    }
}


void encrypt_block(const unsigned char* in, unsigned char* out, const unsigned char* round_keys)
{
    unsigned int word_state[4];
    BytesToMatrix(in, word_state);

    unsigned char state[4][4];
    for (unsigned int i = 0; i < 4; ++i)
    {
        state[0][i] = word_state[i] >> 24;
        state[1][i] = word_state[i] >> 16;
        state[2][i] = word_state[i] >> 8;
        state[3][i] = word_state[i];
    }



    for (unsigned int i = 0; i < 4; ++i)
    {
        for (unsigned int j = 0; j < 4; ++j)
        {
            state[j][i] ^= round_keys[i * 4 + j];
        }

    }



    for (int round = 1; round < 10; ++round)
    {
        for (unsigned int i = 0; i < 4; ++i)
            for (unsigned int j = 0; j < 4; ++j)
                state[i][j] = sbox[state[i][j]];



        unsigned char tmp;
        tmp = state[1][0]; state[1][0] = state[1][1]; state[1][1] = state[1][2]; state[1][2] = state[1][3]; state[1][3] = tmp;
        tmp = state[2][0]; unsigned char tmp2 = state[2][1]; state[2][0] = state[2][2]; state[2][1] = state[2][3]; state[2][2] = tmp; state[2][3] = tmp2;
        tmp = state[3][3]; state[3][3] = state[3][2]; state[3][2] = state[3][1]; state[3][1] = state[3][0]; state[3][0] = tmp;



        for (unsigned int i = 0; i < 4; ++i)
        {
            unsigned char a = state[0][i], b = state[1][i], c = state[2][i], d = state[3][i];
            state[0][i] = galois_multiply(a, 2) ^ galois_multiply(b, 3) ^ c ^ d;
            state[1][i] = a ^ galois_multiply(b, 2) ^ galois_multiply(c, 3) ^ d;
            state[2][i] = a ^ b ^ galois_multiply(c, 2) ^ galois_multiply(d, 3);
            state[3][i] = galois_multiply(a, 3) ^ b ^ c ^ galois_multiply(d, 2);
        }



        for (unsigned int i = 0; i < 4; ++i)
            for (unsigned int j = 0; j < 4; ++j)
                state[j][i] ^= round_keys[round * 16 + i * 4 + j];

    }

    for (unsigned int i = 0; i < 4; ++i)
        for (unsigned int j = 0; j < 4; ++j)
            state[i][j] = sbox[state[i][j]];

    unsigned char tmp;
    tmp = state[1][0];
    state[1][0] = state[1][1];
    state[1][1] = state[1][2];
    state[1][2] = state[1][3];
    state[1][3] = tmp;
    unsigned char tmp2 = state[2][1];
    tmp = state[2][0];
    state[2][0] = state[2][2]; state[2][1] = state[2][3]; state[2][2] = tmp; state[2][3] = tmp2;
    tmp = state[3][3]; state[3][3] = state[3][2]; state[3][2] = state[3][1]; state[3][1] = state[3][0]; state[3][0] = tmp;

    for (unsigned int i = 0; i < 4; ++i)
        for (unsigned int j = 0; j < 4; ++j)
            state[j][i] ^= round_keys[160 + i * 4 + j];

    for (unsigned int i = 0; i < 4; ++i)
    {
        word_state[i] = (static_cast<unsigned int>(state[0][i]) << 24) |
        (static_cast<unsigned int>(state[1][i]) << 16) |
        (static_cast<unsigned int>(state[2][i]) << 8)  |
        (static_cast<unsigned int>(state[3][i]));
    }

    MatrixToBytes(word_state, out);
}

vector<unsigned char> encrypt(const vector<unsigned char>& plaintext, const unsigned char* key, const unsigned char* iv)
{
    unsigned char round_keys[176];
    expand_key(key, round_keys, 10);
    vector<unsigned char> ciphertext(plaintext.size());
    unsigned char shift_register[16];
    for (unsigned int i = 0; i < 16; ++i) shift_register[i] = iv[i];
    unsigned char encrypted_block[16];

    for (unsigned int i = 0; i < plaintext.size(); ++i)
    {
        encrypt_block(shift_register, encrypted_block, round_keys);
        ciphertext[i] = plaintext[i] ^ encrypted_block[0];
        memmove(shift_register, shift_register + 1, 15);
        shift_register[15] = ciphertext[i];
    }
    return ciphertext;
}

vector<unsigned char> decrypt(const vector<unsigned char>& ciphertext, const unsigned char* key, const unsigned char* iv)
{
    unsigned char round_keys[176];
    expand_key(key, round_keys, 10);

    vector<unsigned char> decrypted_text(ciphertext.size());
    unsigned char shift_register[16];
    for (unsigned int i = 0; i < 16; ++i) shift_register[i] = iv[i];
    unsigned char encrypted_block[16];

    for (unsigned int i = 0; i < ciphertext.size(); ++i)
    {
        encrypt_block(shift_register, encrypted_block, round_keys);
        unsigned char current_ciphertext_byte = ciphertext[i];
        decrypted_text[i] = current_ciphertext_byte ^ encrypted_block[0];
        memmove(shift_register, shift_register + 1, 15);
        shift_register[15] = current_ciphertext_byte;
    }
    return decrypted_text;
}

int main()
{
    std::vector<char> big_buffer(1024 * 1024);
    std::cin.rdbuf()->pubsetbuf(big_buffer.data(), big_buffer.size());

    setlocale(LC_ALL, "");

    unsigned char key[16] = {0};
    unsigned char iv[16] = {0};

    random_device rd;
    mt19937 gen(rd());
    uniform_int_distribution<> distr(0, 255);

    cout << "Выберите режим (1 - Шифрование, 2 - Расшифрование): ";
    int mode;
    cin >> mode;
    cin.ignore();

    if (mode == 1)
    {
        for (unsigned int i = 0; i < 16; ++i)
        {
            iv[i] = static_cast<unsigned char>(distr(gen));
            key[i] = static_cast<unsigned char>(distr(gen));
        }

        ofstream key_file("key.txt");
        if (key_file.is_open())
        {
            for (unsigned int i = 0; i < 16; ++i) key_file << hex << (int)key[i] << " "; key_file << "\n";
            key_file.close();
        }

        cout << "Вектор инициализации (IV): ";
        for (unsigned int i = 0; i < 16; ++i) cout << hex << (int)iv[i] << " ";
        cout << "\nСлучайный Ключ: ";
        for (unsigned int i = 0; i < 16; ++i) cout << hex << (int)key[i] << " ";
        cout << dec << "\n";

        cout << dec << "\n";

        cout << "Введите путь к файлу: ";
        string input_line;
        getline(cin, input_line);

        vector<unsigned char> plaintext;
        ifstream check_file(input_line, ios::binary);
        if (check_file.is_open())
        {
            plaintext.assign((istreambuf_iterator<char>(check_file)), istreambuf_iterator<char>());
            check_file.close();
        }
        else
        {
            plaintext.assign(input_line.begin(), input_line.end());
        }
        vector<unsigned char> ciphertext = encrypt(plaintext, key, iv);

        // === ВЫВОД В ФАЙЛ ВМЕСТО КОНСОЛИ ===
        ofstream cipher_file("cipher.txt");
        if (cipher_file.is_open())
        {
            for (unsigned char x : ciphertext) {
                cipher_file << hex << (int)x << " ";
            }
            cipher_file.close();
            cout << "\nЗашифрованный текст сохранён в cipher.txt" << endl;
        }
        else
        {
            cout << "\nОшибка сохранения cipher.txt" << endl;
        }
    }
    else if (mode == 2)
    {
        cout << "Введите ключ: ";
        for (unsigned int i = 0; i < 16; ++i)
        {
            string key_byte;
            cin >> key_byte;
            key[i] = static_cast<unsigned char>(stoul(key_byte, nullptr, 16));
        }

        cout << "Введите вектор инициализации IV: ";
        for (unsigned int i = 0; i < 16; ++i)
        {
            string iv_byte;
            cin >> iv_byte;
            iv[i] = static_cast<unsigned char>(stoul(iv_byte, nullptr, 16));
        }
        cin.ignore();

        cout << "Введите зашифрованный текст или путь к файлу: ";
        string cipher_input;
        getline(cin, cipher_input);

        vector<unsigned char> ciphertext;
        string token = "";
        ifstream check_file(cipher_input);
        if (check_file.is_open())
        {
            while (check_file >> token)
            {
                ciphertext.push_back(static_cast<unsigned char>(stoul(token, nullptr, 16)));
            }
            check_file.close();
        }
        else
        {
            for (char ch : cipher_input)
            {
                if (ch == ' ')
                {
                    if (!token.empty())
                    {
                        ciphertext.push_back(static_cast<unsigned char>(stoul(token, nullptr, 16)));
                        token = "";
                    }
                }
                else
                {
                    token += ch;
                }
            }
            if (!token.empty())
            {
                ciphertext.push_back(static_cast<unsigned char>(stoul(token, nullptr, 16)));
            }
        }

        vector<unsigned char> decrypted = decrypt(ciphertext, key, iv);

        // === ВЫВОД В ФАЙЛ ВМЕСТО КОНСОЛИ ===
        ofstream decrypted_file("decrypted.txt");
        if (decrypted_file.is_open())
        {
            decrypted_file.write(reinterpret_cast<const char*>(decrypted.data()), decrypted.size());
            decrypted_file.close();
            cout << "\nРасшифрованный текст сохранён в decrypted.txt" << endl;
        }
        else
        {
            cout << "\nОшибка сохранения decrypted.txt" << endl;
        }
    }
}
