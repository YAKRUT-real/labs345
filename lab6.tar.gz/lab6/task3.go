package main

import (
	"fmt"
)

func main() {
	A := [4][4]float64{
		{1.25, -0.04, 0.21, -1.16},
		{0.25, -1.23, -1.14, -0.09},
		{-0.21, -1.14, 0.8, -0.13},
		{0.15, -1.31, 0.06, -1.09},
	}

	b := [4]float64{-1.24, -1.09, 2.56, 1.25}

	var L [4][4]float64
	var U [4][4]float64

	for i := 0; i < 4; i++ {
		L[i][i] = 1.0
	}

	fmt.Println("\nИсходная матрица A:")
	for i := 0; i < 4; i++ {
		for j := 0; j < 4; j++ {
			fmt.Printf("%10.6f ", A[i][j])
		}
		fmt.Printf("| %10.6f\n", b[i])
	}

	for i := 0; i < 4; i++ {
		for j := i; j < 4; j++ {
			sum := 0.0
			for k := 0; k < i; k++ {
				sum += L[i][k] * U[k][j]
			}
			U[i][j] = A[i][j] - sum
		}
		for j := i + 1; j < 4; j++ {
			sum := 0.0
			for k := 0; k < i; k++ {
				sum += L[j][k] * U[k][i]
			}
			L[j][i] = (A[j][i] - sum) / U[i][i]
		}
	}

	fmt.Println("\nМатрица L:")
	for i := 0; i < 4; i++ {
		for j := 0; j < 4; j++ {
			fmt.Printf("%10.6f ", L[i][j])
		}
		fmt.Println()
	}

	fmt.Println("\nМатрица U:")
	for i := 0; i < 4; i++ {
		for j := 0; j < 4; j++ {
			fmt.Printf("%10.6f ", U[i][j])
		}
		fmt.Println()
	}

	fmt.Println("\nПроверка: L * U:")
	for i := 0; i < 4; i++ {
		for j := 0; j < 4; j++ {
			sum := 0.0
			for k := 0; k < 4; k++ {
				sum += L[i][k] * U[k][j]
			}
			fmt.Printf("%10.6f ", sum)
		}
		fmt.Println()
	}

	det := 1.0
	for i := 0; i < 4; i++ {
		det *= U[i][i]
	}
	fmt.Printf("\nОпределитель матрицы A: %10.6f\n", det)

	var y [4]float64
	for i := 0; i < 4; i++ {
		sum := 0.0
		for j := 0; j < i; j++ {
			sum += L[i][j] * y[j]
		}
		y[i] = b[i] - sum
	}

	fmt.Println("\nПрямой ход (L*y = b):")
	for i := 0; i < 4; i++ {
		fmt.Printf("y[%d] = %10.6f\n", i+1, y[i])
	}

	var x [4]float64
	for i := 3; i >= 0; i-- {
		sum := 0.0
		for j := i + 1; j < 4; j++ {
			sum += U[i][j] * x[j]
		}
		x[i] = (y[i] - sum) / U[i][i]
	}

	fmt.Println("\nОбратный ход (U*x = y):")
	for i := 0; i < 4; i++ {
		fmt.Printf("x[%d] = %10.6f\n", i+1, x[i])
	}

	fmt.Println("\nПроверка решения A*x = b:")
	for i := 0; i < 4; i++ {
		sum := 0.0
		for j := 0; j < 4; j++ {
			sum += A[i][j] * x[j]
		}
		fmt.Printf("Строка %d: %10.6f (должно быть %10.6f)\n", i+1, sum, b[i])
	}

	fmt.Printf("x1 = %10.6f\n", x[0])
	fmt.Printf("x2 = %10.6f\n", x[1])
	fmt.Printf("x3 = %10.6f\n", x[2])
	fmt.Printf("x4 = %10.6f\n", x[3])
}
