package main

import (
	"fmt"
	"math"
)

const MAX = int(1e9)

var n, m int
var a [][]int

func printBoard(board [][]int) {
	for i := 0; i < len(board); i++ {
		for j := 0; j < len(board[i]); j++ {
			fmt.Printf("%d ", board[i][j])
		}
		fmt.Println()
	}
	fmt.Println()
}

func soluf(borderValue int) int {
	target := make([][]int, n)
	for i := 0; i < n; i++ {
		target[i] = make([]int, m)
		for j := 0; j < m; j++ {
			if i == 0 || i == n-1 || j == 0 || j == m-1 {
				target[i][j] = borderValue
			} else {
				target[i][j] = 1 - borderValue
			}
		}
	}

	T := make([][2]int, 0)
	for i := 0; i < n; i++ {
		for j := 0; j < m; j++ {
			if a[i][j] != target[i][j] {
				T = append(T, [2]int{i, j})
			}
		}
	}

	if len(T) == 0 {
		return 0
	}

	if len(T)%2 != 0 {
		return MAX
	}

	k := len(T)
	dp := make([]int, 1<<k)
	for i := 0; i < len(dp); i++ {
		dp[i] = MAX
	}
	dp[0] = 0

	for mask := 0; mask < (1 << k); mask++ {
		if dp[mask] == MAX {
			continue
		}

		first := -1
		for i := 0; i < k; i++ {
			if (mask & (1 << i)) == 0 {
				first = i
				break
			}
		}

		if first == -1 {
			continue
		}

		for j := first + 1; j < k; j++ {
			if (mask & (1 << j)) == 0 {
				newMask := mask | (1 << first) | (1 << j)
				dist := int(math.Abs(float64(T[first][0]-T[j][0])) + math.Abs(float64(T[first][1]-T[j][1])))
				if dp[mask]+dist < dp[newMask] {
					dp[newMask] = dp[mask] + dist
				}
			}
		}
	}

	return dp[(1<<k)-1]
}

func main() {
	fmt.Scan(&n, &m)

	a = make([][]int, n)
	for i := 0; i < n; i++ {
		a[i] = make([]int, m)
		for j := 0; j < m; j++ {
			fmt.Scan(&a[i][j])
		}
	}

	ans1 := soluf(0)
	ans2 := soluf(1)

	ans := ans1
	if ans2 < ans {
		ans = ans2
	}

	if ans >= MAX {
		fmt.Println(-1)
	} else {
		fmt.Println(ans)
	}
}
