package main

import (
	"bufio"
	"fmt"
	"math"
	"os"
	"strconv"
	"strings"
)

func intPow(base int64, exp int) int64 {
	result := int64(1)
	for i := 0; i < exp; i++ {
		result *= base
	}
	return result
}

func gcd(a, b int64) int64 {
	a = int64(math.Abs(float64(a)))
	b = int64(math.Abs(float64(b)))
	for b != 0 {
		t := b
		b = a % b
		a = t
	}
	return a
}

func computeEulerian(maxA int) [][]int64 {
	euler := make([][]int64, maxA+1)
	for i := range euler {
		euler[i] = make([]int64, maxA+1)
	}
	euler[0][0] = 1
	for n := 1; n <= maxA; n++ {
		for k := 0; k < n; k++ {
			var left int64
			if k > 0 {
				left = int64(n-k) * euler[n-1][k-1]
			} else {
				left = 0
			}
			right := int64(k+1) * euler[n-1][k]
			euler[n][k] = left + right
		}
	}

	return euler
}

func main() {
	reader := bufio.NewReader(os.Stdin)

	fmt.Print("Введите a и b: ")
	input, _ := reader.ReadString('\n')
	input = strings.TrimSpace(input)
	parts := strings.Split(input, " ")

	if len(parts) < 2 {
		fmt.Println("Ошибка. Нужно два числа")
		return
	}

	a, err1 := strconv.Atoi(parts[0])
	b, err2 := strconv.Atoi(parts[1])

	if err1 != nil || err2 != nil {
		fmt.Println("Ошибка. нужны целые числа")
		return
	}

	if b == 1 {
		fmt.Println("infinity")
		return
	}
	euler := computeEulerian(a)
	var numerator int64 = 0
	for k := 0; k < a; k++ {
		numerator += euler[a][k] * intPow(int64(b), a-k)
	}
	denominator := intPow(int64(b-1), a+1)
	g := gcd(numerator, denominator)
	numerator /= g
	denominator /= g

	fmt.Printf("%d/%d\n", numerator, denominator)
}
