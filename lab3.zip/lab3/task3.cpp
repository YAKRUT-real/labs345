#include <iostream>
#include <cstdint>
#include <vector>

using namespace std;

int64_t int_pow(int64_t base, int exp) {
    int64_t result = 1;
    for (int i = 0; i < exp; ++i) {
        result *= base;
    }
    return result;
}

int64_t gcd(int64_t a, int64_t b) {
    a = abs(a);
    b = abs(b);
    while (b != 0) {
        int64_t t = b;
        b = a % b;
        a = t;
    }
    return a;
}

vector<vector<int64_t>> compute_eulerian(int max_a) {
    vector<vector<int64_t>> euler(max_a + 1, vector<int64_t>(max_a + 1, 0));
    euler[0][0] = 1;
    
    for (int n = 1; n <= max_a; ++n) {
        for (int k = 0; k < n; ++k) {
            int64_t left = (n - k) * (k > 0 ? euler[n-1][k-1] : 0);
            int64_t right = (k + 1) * euler[n-1][k];
            euler[n][k] = left + right;
        }
    }
    
    return euler;
}

int main() {
    int a, b;
    cin >> a >> b;
    
    if (b == 1) {
        cout << "infinity" << endl;
        return 0;
    }
    auto euler = compute_eulerian(a);
    int64_t numerator = 0;
    for (int k = 0; k < a; ++k) {
        numerator += euler[a][k] * int_pow(b, a - k);
    }
    int64_t denominator = int_pow(b - 1, a + 1);
    int64_t g = gcd(numerator, denominator);
    numerator /= g;
    denominator /= g;
    cout << numerator << "/" << denominator << endl;
    
    return 0;
}
