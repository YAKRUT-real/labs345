#include <iostream>
#include <cmath>
#include <iomanip>

using namespace std;


double exp_func(double x) {
    double exponent = 1.0612 * x - 0.4293;
    return 0.74268 * pow(2.0, exponent) - 3.74268;
}

double f(double x) {
    if (x <= -3.0) {
        return -x - 6.0;
    }
    else if (x <= 0.0) {
        return -1.5 * x * x - 4.5 * x - 3.0;
    }
    else if (x <= 3.0) {
        return exp_func(x);
    }
    else {
        return -1.5 * x + 7.5;
    }
}

int main() {
    double x_start, x_end, dx;
    
    cout << "Введите Xнач, Xкон, dx: ";
    cin >> x_start >> x_end >> dx;
    
    cout << fixed << setprecision(4);
    cout << "\n   x       y\n";
    cout << "----------------\n";
    
    for (double x = x_start; x <= x_end + 1e-9; x += dx) {
        cout << setw(8) << x << setw(10) << f(x) << endl;
    }


    return 0;
}
