#include <iostream>
#include <vector>
#include <iomanip>
#include <cmath>
#include <algorithm>
#include <cstdint>
#include <cstdlib>

using namespace std;
using uint64 = unsigned long long;

vector<uint64> sieveEratosthenes() {
    const int limit = 500;
    vector<bool> isPrime(limit + 1, true);
    isPrime[0] = isPrime[1] = false;
    for (int i = 2; i * i <= limit; ++i)
        if (isPrime[i])
            for (int j = i * i; j <= limit; j += i)
                isPrime[j] = false;

    vector<uint64> primes;
    for (int i = 2; i <= limit; ++i)
        if (isPrime[i]) primes.push_back(i);
    return primes;
}

uint64 powmod(uint64 a, uint64 b, uint64 m) {
    uint64 res = 1;
    a %= m;
    while (b) {
        if (b & 1) res = (__int128)res * a % m;
        a = (__int128)a * a % m;
        b >>= 1;
    }
    return res;
}

uint64 gcd(uint64 a, uint64 b) {
    while (b) {
        uint64 t = b;
        b = a % b;
        a = t;
    }
    return a;
}

bool poclingtonTest(uint64 n, const vector<uint64>& q, int t) {
    if (n < 2) return false;
    if (n == 2 || n == 3) return true;
    if (n % 2 == 0) return false;

    uint64 n1 = n - 1;

    vector<uint64> aList = {2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37};
    if (t > (int)aList.size()) t = aList.size();

    for (int i = 0; i < t; ++i) {
        uint64 a = aList[i];
        if (a >= n) continue;
        if (powmod(a, n1, n) != 1) return false;
    }

    for (uint64 qi : q) {
        if (qi >= n) continue;
        uint64 exp = n1 / qi;
        bool foundGood = false;
        for (int i = 0; i < t; ++i) {
            uint64 a = aList[i];
            if (a >= n) continue;
            uint64 val = powmod(a, exp, n);
            uint64 g = gcd(val - 1, n);
            if (g == 1) {
                foundGood = true;
                break;
            }
        }
        if (!foundGood) return false;
    }

    return true;
}

bool buildF(int bits, const vector<uint64>& smallPrimes,
            uint64& F, vector<uint64>& q, int& attempts) {
    attempts = 0;

    uint64 minF = 1ULL << (bits / 2);
    uint64 maxN = (bits == 64) ? UINT64_MAX : (1ULL << bits);
    uint64 maxF = maxN / 4;

    while (attempts < 10000) {
        attempts++;
        F = 1;
        q.clear();

        vector<uint64> shuffled = smallPrimes;
        for (size_t i = 0; i < shuffled.size(); ++i) {
            size_t j = rand() % shuffled.size();
            swap(shuffled[i], shuffled[j]);
        }

        for (uint64 p : shuffled) {
            if (F >= minF && F * p > maxF) break;
            if (F > UINT64_MAX / p) continue;

            int maxAlpha = 1;
            if (p <= 7) maxAlpha = 2;
            if (p <= 3 && bits > 20) maxAlpha = 3;

            int alpha = 1 + (rand() % maxAlpha);
            uint64 factor = 1;
            bool overflow = false;
            for (int i = 0; i < alpha; ++i) {
                if (factor > UINT64_MAX / p) { overflow = true; break; }
                factor *= p;
            }
            if (overflow) continue;
            if (F > UINT64_MAX / factor) continue;
            if (F * factor > maxF) continue;

            F *= factor;
            q.push_back(p);
        }

        if (F >= minF && F <= maxF && F > 0) {
            return true;
        }
    }
    return false;
}

uint64 buildR(uint64 F, int bits) {
    if (F <= 4) return 2;

    uint64 maxN = (bits == 64) ? UINT64_MAX : (1ULL << bits);
    uint64 maxR = (maxN - 1) / F;

    if (maxR < 2) return 0;

    for (int attempt = 0; attempt < 200; ++attempt) {
        uint64 R = 2 + (rand() % (maxR - 1));
        if (R % 2 == 1) R++;
        if (R >= 2 && R <= maxR) return R;
    }
    return 2;
}

bool generatePrime(int bits, int t, uint64& result, int& rejected,
                   const vector<uint64>& smallPrimes) {
    rejected = 0;

    uint64 maxN = (bits == 64) ? UINT64_MAX : (1ULL << bits);
    uint64 minN = (bits == 1) ? 2 : (1ULL << (bits - 1));

    while (true) {
        uint64 F;
        vector<uint64> q;
        int buildAttempts;

        if (!buildF(bits, smallPrimes, F, q, buildAttempts)) {
            rejected++;
            continue;
        }

        uint64 R = buildR(F, bits);
        if (R == 0 || R % 2 != 0) {
            rejected++;
            continue;
        }

        __int128 n128 = (__int128)R * F + 1;
        if (n128 > maxN || n128 < minN) {
            rejected++;
            continue;
        }
        uint64 n = (uint64)n128;

        if (gcd(R, F) != 1) {
            rejected++;
            continue;
        }

        long double sqrtN = sqrtl((long double)(n - 1));
        if (F <= (uint64)sqrtN) {
            rejected++;
            continue;
        }

        if (!poclingtonTest(n, q, t)) {
            rejected++;
            continue;
        }

        if (!poclingtonTest(n, q, 2)) {
            rejected++;
            continue;
        }

        result = n;
        return true;
    }
}

int main() {
    vector<uint64> smallPrimes = sieveEratosthenes();

    int bits;
    cout << "Введите разрядность чисел (1-64): ";
    cin >> bits;

    if (bits < 1 || bits > 64) {
        cerr << "Разрядность должна быть от 1 до 64" << endl;
        return 1;
    }

    const int COUNT = 10;
    uint64 primes[COUNT];
    int rejected[COUNT];

    cout << "\nГенерация " << COUNT << " простых чисел разрядностью " << bits << " бит..." << endl;
    cout << "Диапазон чисел: [" << (bits == 1 ? 2 : (1ULL << (bits-1)))
         << ", " << (bits == 64 ? "2^64-1" : to_string((1ULL << bits) - 1)) << "]\n" << endl;

    for (int i = 0; i < COUNT; ++i) {
        if (!generatePrime(bits, 3, primes[i], rejected[i], smallPrimes)) {
            cerr << "Ошибка: не удалось сгенерировать число " << i+1 << endl;
            return 1;
        }
        cout << "Число " << i+1 << ": " << primes[i] << " (отвергнуто: " << rejected[i] << ")" << endl;
    }

    cout << "\n\n";

    cout << "номер                  ";
    for (int i = 1; i <= COUNT; ++i) {
        cout << setw(12) << i;
    }
    cout << "\n";
    cout << string(14 + COUNT * 12, '-') << "\n";

    cout << "простое число          ";
    for (int i = 0; i < COUNT; ++i) {
        cout << setw(12) << primes[i];
    }
    cout << "\n";
    cout << string(14 + COUNT * 12, '-') << "\n";

    cout << "Результат проверки\n";
    cout << "тестом на простоту    ";
    for (int i = 0; i < COUNT; ++i) {
        cout << setw(12) << "true";
    }
    cout << "\n";
    cout << string(14 + COUNT * 12, '-') << "\n";

    cout << "количество отвергнутых\n";
    cout << "чисел (rejected)      ";
    for (int i = 0; i < COUNT; ++i) {
        cout << setw(12) << rejected[i];
    }
    cout << "\n";

    return 0;
}
