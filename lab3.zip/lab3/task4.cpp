#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main() {
    int n, m;
    cin >> n >> m;
    vector<int64_t> arr(n);
    for (int i = 0; i < n; i++) cin >> arr[i];

    vector<int64_t> prefix(n+1, 0);
    for (int i = 0; i < n; i++) prefix[i+1] = prefix[i] + arr[i];

    int64_t scorePavel = 0, scoreVika = 0;
    int lastMovePavel = 0, lastMoveVika = 0;
    int pos = 0;
    bool isPavelTurn = true;

    while (pos < n) {
        int remaining = n - pos;
        int maxTake = min(m, remaining);

        int bestK = -1;
        int64_t bestSum = -9e18;

        for (int k = 1; k <= maxTake; k++) {
            if ((isPavelTurn && k == lastMovePavel) ||
                (!isPavelTurn && k == lastMoveVika)) continue;

            int64_t sum = prefix[pos + k] - prefix[pos];
            if (sum > bestSum || (sum == bestSum && k < bestK)) {
                bestSum = sum;
                bestK = k;
            }
        }

        if (isPavelTurn) {
            scorePavel += bestSum;
            lastMovePavel = bestK;
        } else {
            scoreVika += bestSum;
            lastMoveVika = bestK;
        }
        pos += bestK;
        isPavelTurn = !isPavelTurn;
    }
    cout << (scorePavel > scoreVika ? 1 : 0) << endl;
    return 0;
}
