#include <iostream>
#include <random>
#include <cmath>
#include <map>
#include <algorithm>

using namespace std;

void print(int* a, int n) { for (int i = 0; i < n; i++) cout << a[i] << " "; cout << endl; }

int main() {
    mt19937 rng(6767);
    uniform_int_distribution<int> d1(0, 100), d2(-10, 10);
    //1
    int n = 12, a[12];
    for (int i = 0; i < n; i++) a[i] = d1(rng);
    cout << "1: "; print(a, n);
    
    //2
    double sum = 0, mean, ss = 0;
    for (int i = 0; i < n; i++) sum += a[i];
    mean = sum / n;
    for (int i = 0; i < n; i++) ss += pow(a[i] - mean, 2);
    cout << "2: mean=" << mean << " sum_sq=" << ss << endl;

    //3
    int b[12];
    for (int i = 0; i < n; i++) b[i] = a[i];
    sort(b, b + n);
    int min2 = b[1], max3 = b[n-3];
    for (int i = 0; i < n; i++) {
        if (a[i] == min2) { min2 = i; break; }
    }
    for (int i = 0; i < n; i++) {
        if (a[i] == max3) { max3 = i; break; }
    }
    swap(a[min2], a[max3]);
    cout << "3: swapped: "; print(a, n);
    
    //4
    int c[12];
    for (int i = 0; i < n; i++) c[i] = a[i];
    cout << "4: before: "; print(c, n);
    int t2[12];
    for (int i = 0; i < n; i++) t2[i] = c[(i + 2) % n];
    for (int i = 0; i < n; i++) c[i] = t2[i];
    cout << "   after:  "; print(c, n);
    
    //5
    int m = 25, d[25];
    for (int i = 0; i < m; i++) d[i] = d2(rng);
    cout << "5: array: "; print(d, m);
    
    map<int, int> f;
    for (int i = 0; i < m; i++) f[d[i]]++;
    
    int maxRep = -11;
    for (auto& p : f) if (p.second > 1 && p.first > maxRep) maxRep = p.first;
    
    cout << "   frequencies: ";
    for (auto& p : f) cout << p.first << ":" << p.second << " ";
    cout << endl;
    if (maxRep > -11) {
        for (int i = 0; i < m; i++) if (f[d[i]] > 1) d[i] = maxRep;
        cout << "   replaced: "; print(d, m);
    } else cout << "   no repeats" << endl;
    
    return 0;
}
