#include <iostream>
#include <vector>
#include <cstdlib>
#include <ctime>
#include <string>
#include <algorithm>

using namespace std;
typedef bool (*Algorithm)(int round, const vector<bool>& self, const vector<bool>& enemy);
bool Mechetsa(int round, const vector<bool>& self, const vector<bool>& enemy) {
    if (round == 0) return true;
    return enemy.back();
}
bool Zloy(int round, const vector<bool>& self, const vector<bool>& enemy) {
    return false;
}
bool Obida(int round, const vector<bool>& self, const vector<bool>& enemy) {
    for (bool e : enemy) {
        if (!e) return false;
    }
    return true;
}

void calculateScores(bool choice1, bool choice2, int& score1, int& score2) {
    if (choice1 && choice2) {
        score1 += 24;
        score2 += 24;
    } else if (choice1 && !choice2) {
        score1 += 0;
        score2 += 20;
    } else if (!choice1 && choice2) {
        score1 += 20;
        score2 += 0;
    } else {
        score1 += 4;
        score2 += 4;
    }
}


void playGame(Algorithm alg1, Algorithm alg2, const string& name1, const string& name2, int rounds) {
    vector<bool> choices1, choices2;
    int score1 = 0, score2 = 0;

    cout << "\n=== " << name1 << " vs " << name2 << " ===" << endl;
    cout << "Раундов: " << rounds << endl;

    for (int round = 0; round < rounds; round++) {
        bool c1 = alg1(round, choices1, choices2);
        bool c2 = alg2(round, choices2, choices1);

        choices1.push_back(c1);
        choices2.push_back(c2);

        calculateScores(c1, c2, score1, score2);
    }

    cout << "Счёт: " << name1 << " = " << score1 << ", " << name2 << " = " << score2 << endl;
    if (score1 > score2) cout << "Победитель: " << name1 << endl;
    else if (score2 > score1) cout << "Победитель: " << name2 << endl;
    else cout << "Ничья" << endl;
}

int main() {
    setlocale(LC_ALL, "Russian");
    srand(time(0));
    int rounds = 10000 + rand() % 10000;

    cout << "ИГРА «ДИЛЕММА ЗАКЛЮЧЁННОГО»" << endl;
    cout << "Всего раундов: " << rounds << endl;

    Algorithm alg1 = Mechetsa;
    Algorithm alg2 = Zloy;
    Algorithm alg3 = Obida;

    string name1 = "Око за око";
    string name2 = "Всегда предавать";
    string name3 = "Добрый до первого предательства";

    playGame(alg1, alg2, name1, name2, rounds);

    playGame(alg1, alg3, name1, name3, rounds);

    playGame(alg2, alg3, name2, name3, rounds);

    return 0;
}
