#include <iostream>
#include <cmath>
#include <iomanip>
#include <vector>

using namespace std;
double f(double x) {
    return 2 * log(x) - 0.5 * x + 1;
}
double df(double x) {
    return 2.0 / x - 0.5;
}
double phi(double x) {
    return 4 * log(x) + 2;
}

int main() {
    setlocale(LC_ALL, "Russian");
    cout << fixed << setprecision(6);
    double eps = 1e-4;

    cout << "МЕТОД ПОЛОВИННОГО ДЕЛЕНИЯ\n";
    cout << "N       a_n         b_n         b_n - a_n\n";

    double a = 0.5, b = 1.0;
    int n = 0;
    double c;

    while ((b - a) > eps) {
        c = (a + b) / 2;
        cout << n << "   " << a << "   " << b << "   " << (b - a) << "\n";

        if (f(a) * f(c) < 0)
            b = c;
        else
            a = c;

        n++;
    }

    double root1 = (a + b) / 2;
    cout << "\nКорень: " << root1 << "\n\n";
    cout << "МЕТОД НЬЮТОНА\n";
    cout << "N       x_n         x_{n+1}       |x_{n+1} - x_n|\n";

    double x0 = 0.75;
    double x1;
    n = 0;

    do {
        x1 = x0 - f(x0) / df(x0);
        cout << n << "   " << x0 << "   " << x1 << "   " << fabs(x1 - x0) << "\n";
        x0 = x1;
        n++;
    } while (fabs(x1 - x0) > eps);

    double root2 = x1;
    cout << "\nКорень: " << root2 << "\n\n";
    cout << "МЕТОД ПРОСТЫХ ИТЕРАЦИЙ\n";
    cout << "N       x_n         x_{n+1}       |x_{n+1} - x_n|\n";

    x0 = 0.75;
    n = 0;

    do {
        x1 = phi(x0);
        cout << n << "   " << x0 << "   " << x1 << "   " << fabs(x1 - x0) << "\n";
        x0 = x1;
        n++;

        if (n > 1000) {
            cout << "Превышено число итераций (метод может расходиться)\n";
            break;
        }
    } while (fabs(x1 - x0) > eps);

    double root3 = x1;
    cout << "\nКорень: " << root3 << "\n\n";
    cout << "СРАВНЕНИЕ МЕТОДОВ ПО СКОРОСТИ СХОДИМОСТИ\n";
    cout << "Метод               | Итераций | Скорость\n";
    cout << "Половинного деления | ~" << n << "       | линейная (медленная)\n";
    cout << "Ньютона             | ~" << (n < 10 ? "5" : "?") << "        | квадратичная (быстрая)\n";
    cout << "Простых итераций    | ~" << n << "       | линейная (зависит от q)\n";

    return 0;
}
