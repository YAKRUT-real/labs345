#include <iostream>
#include <vector>
#include <unordered_map>

using namespace std;

int main() {
    setlocale(LC_ALL, "Russian");
    int X0, A, B, C, N;
    cout << "Формула линейного конгруэнтного генератора X[i] = (A * X[i-1] + B) mod C" << endl << endl;
    cout << "Введите X0 (начальное значение): ";
    cin >> X0;
    cout << "Введите A (множитель): ";
    cin >> A;
    cout << "Введите B (приращение): ";
    cin >> B;
    cout << "Введите C (модуль): ";
    cin >> C;
    cout << "Введите N (максимальное количество чисел): ";
    cin >> N;
    vector<int> sequence;
    unordered_map<int, int> indexMap;
    int current = X0;
    int repeatIndex = -1;
    int sequenceLength = 0;
    for (int i = 0; i < N; i++) {
        if (i > 0) {
            current = (A * current + B) % C;
        } else {
            current = X0;
        }
        if (indexMap.find(current) != indexMap.end()) {
            repeatIndex = indexMap[current];
            sequenceLength = i;
            cout << current << " ";
            sequence.push_back(current);
            cout << "\n\nПовторение обнаружено!" << endl;
            cout << "Число " << current << " уже встречалось на позиции " << repeatIndex + 1 << endl;
            cout << "Период последовательности: " << i - repeatIndex << endl;
            cout << "Последовательность зацикливается с " << repeatIndex + 1 << "-го элемента" << endl;

            sequenceLength = i + 1;
            break;
        }
        indexMap[current] = i;
        sequence.push_back(current);
        cout << current << " ";
    }
    if (repeatIndex == -1) {
        cout << "\n\nПовторение не обнаружено за " << N << " чисел" << endl;
        sequenceLength = N;
    }
    cout << "\n\nПолная последовательность:" << endl;
    for (int i = 0; i < sequence.size(); i++) {
        cout << sequence[i];
        if (i < sequence.size() - 1) cout << " → ";
    }
    cout << endl;
    cout << "Максимальный период: " << C << endl;
    if (B == 0) {
        cout << "Тип: мультипликативный" << endl;
    } else {
        cout << "Тип: смешанный" << endl;
    }
    bool fullPeriod = false;
    if (B != 0) {
        int Ctemp = C;
        if (C % 4 == 0 && (A - 1) % 4 != 0) {
            fullPeriod = false;
        } else {
            fullPeriod = true;
        }
    }

    if (fullPeriod && repeatIndex == -1) {
        cout << "Возможен максимальный период = " << C << endl;
    }

    return 0;
}
