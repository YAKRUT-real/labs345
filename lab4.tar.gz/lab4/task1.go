package main

import (
	"fmt"
	"math"
)

func f(x float64) float64 {
	return 2*math.Log(x) - 0.5*x + 1
}

func df(x float64) float64 {
	return 2.0/x - 0.5
}

func phi(x float64) float64 {
	return 4*math.Log(x) + 2
}

func main() {
	eps := 1e-4

	fmt.Println("МЕТОД ПОЛОВИННОГО ДЕЛЕНИЯ")
	fmt.Println("N       a_n         b_n         b_n - a_n")

	a, b := 0.5, 1.0
	n := 0
	var c float64

	for (b - a) > eps {
		c = (a + b) / 2
		fmt.Printf("%d   %.6f   %.6f   %.6f\n", n, a, b, b-a)

		if f(a)*f(c) < 0 {
			b = c
		} else {
			a = c
		}
		n++
	}

	root1 := (a + b) / 2
	fmt.Printf("\nКорень: %.6f\n\n", root1)

	fmt.Println("МЕТОД НЬЮТОНА")
	fmt.Println("N       x_n         x_{n+1}       |x_{n+1} - x_n|")

	x0 := 0.75
	var x1 float64
	n = 0

	for {
		x1 = x0 - f(x0)/df(x0)
		fmt.Printf("%d   %.6f   %.6f   %.6f\n", n, x0, x1, math.Abs(x1-x0))
		x0 = x1
		n++

		if math.Abs(x1-x0) <= eps {
			break
		}
	}

	root2 := x1
	fmt.Printf("\nКорень: %.6f\n\n", root2)

	fmt.Println("МЕТОД ПРОСТЫХ ИТЕРАЦИЙ")
	fmt.Println("N       x_n         x_{n+1}       |x_{n+1} - x_n|")

	x0 = 0.75
	n = 0

	for {
		x1 = phi(x0)
		fmt.Printf("%d   %.6f   %.6f   %.6f\n", n, x0, x1, math.Abs(x1-x0))
		x0 = x1
		n++

		if n > 1000 {
			fmt.Println("Превышено число итераций (метод может расходиться)")
			break
		}

		if math.Abs(x1-x0) <= eps {
			break
		}
	}

	root3 := x1
	fmt.Printf("\nКорень: %.6f\n\n", root3)

	fmt.Println("СРАВНЕНИЕ МЕТОДОВ ПО СКОРОСТИ СХОДИМОСТИ")
	fmt.Println("Метод               | Итераций | Скорость")
	fmt.Printf("Половинного деления | ~%d       | линейная (медленная)\n", n)
	fmt.Println("Ньютона             | ~5        | квадратичная (быстрая)")
	fmt.Printf("Простых итераций    | ~%d       | линейная (зависит от q)\n", n)
}
