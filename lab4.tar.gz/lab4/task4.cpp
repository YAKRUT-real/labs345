#include <iostream>
#include <vector>
#include <string>
#include <map>
#include <algorithm>
#include <iomanip>

using namespace std;
struct Candidate {
    string name;
    int bordaScore;
};
string bordaWinner(const vector<vector<string>>& votes, const vector<string>& candidates) {
    int n = candidates.size();
    map<string, int> scores;
    for (const auto& c : candidates) {
        scores[c] = 0;
    }
    for (const auto& vote : votes) {
        for (int pos = 0; pos < n; pos++) {
            scores[vote[pos]] += (n - 1 - pos);
        }
    }
    int maxScore = -1;
    string winner;
    for (const auto& c : candidates) {
        cout << c << ": " << scores[c] << " очков" << endl;
        if (scores[c] > maxScore) {
            maxScore = scores[c];
            winner = c;
        }
    }

    return winner;
}
string condorcetWinner(const vector<vector<string>>& votes, const vector<string>& candidates) {
    int n = candidates.size();
    int k = votes.size();
    map<pair<string, string>, int> wins;
    for (const auto& c1 : candidates) {
        for (const auto& c2 : candidates) {
            if (c1 != c2) {
                wins[{c1, c2}] = 0;
            }
        }
    }
    for (const auto& vote : votes) {
        map<string, int> position;
        for (int pos = 0; pos < n; pos++) {
            position[vote[pos]] = pos;
        }
        for (int i = 0; i < n; i++) {
            for (int j = i + 1; j < n; j++) {
                string a = vote[i];
                string b = vote[j];
                wins[{a, b}]++;
            }
        }
    }
    vector<string> condorcetWinners;
    for (const auto& c1 : candidates) {
        bool isWinner = true;
        for (const auto& c2 : candidates) {
            if (c1 != c2) {
                if (wins[{c1, c2}] <= k / 2) {
                    isWinner = false;
                    break;
                }
            }
        }
        if (isWinner) {
            condorcetWinners.push_back(c1);
        }
    }

    if (condorcetWinners.size() == 1) {
        return condorcetWinners[0];
    } else if (condorcetWinners.empty()) {
        return "НЕ ОПРЕДЕЛЁН (парадокс Кондорсе)";
    } else {
        return "НЕ ОПРЕДЕЛЁН (ничья)";
    }
}

int main() {
    setlocale(LC_ALL, "Russian");
    int k;
    cout << "Введите количество избирателей: ";
    cin >> k;

    int n;
    cout << "Введите количество кандидатов: ";
    cin >> n;

    vector<string> candidates(n);
    cout << "Введите имена кандидатов: ";
    for (int i = 0; i < n; i++) {
        cin >> candidates[i];
    }
    vector<vector<string>> votes(k);
    cout << "\nВведите голоса (ранжирование от 1-го места к последнему):" << endl;
    for (int i = 0; i < k; i++) {
        cout << "Избиратель " << i + 1 << ": ";
        votes[i].resize(n);
        for (int j = 0; j < n; j++) {
            cin >> votes[i][j];
        }
    }
    string bordaWin = bordaWinner(votes, candidates);
    cout << "По Борду: " << bordaWin << endl;
    string condorcetWin = condorcetWinner(votes, candidates);
    cout << "По Кондорсе: " << condorcetWin << endl;
    if (bordaWin == condorcetWin) {
        cout << "\nСОВПАДАЮТ!" << endl;
    } else {
        cout << "\nРАЗНЫЕ!" << endl;
        cout << "Это нормально для теории голосований" << endl;
    }

    return 0;
}
