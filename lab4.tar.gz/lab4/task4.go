package main

import (
	"fmt"
)

type Candidate struct {
	name       string
	bordaScore int
}

func bordaWinner(votes [][]string, candidates []string) string {
	n := len(candidates)
	scores := make(map[string]int)

	for _, c := range candidates {
		scores[c] = 0
	}

	for _, vote := range votes {
		for pos := 0; pos < n; pos++ {
			scores[vote[pos]] += (n - 1 - pos)
		}
	}

	maxScore := -1
	winner := ""
	for _, c := range candidates {
		fmt.Printf("%s: %d очков\n", c, scores[c])
		if scores[c] > maxScore {
			maxScore = scores[c]
			winner = c
		}
	}

	return winner
}

func condorcetWinner(votes [][]string, candidates []string) string {
	n := len(candidates)
	k := len(votes)
	wins := make(map[[2]string]int)

	for _, c1 := range candidates {
		for _, c2 := range candidates {
			if c1 != c2 {
				wins[[2]string{c1, c2}] = 0
			}
		}
	}

	for _, vote := range votes {
		position := make(map[string]int)
		for pos := 0; pos < n; pos++ {
			position[vote[pos]] = pos
		}
		for i := 0; i < n; i++ {
			for j := i + 1; j < n; j++ {
				a := vote[i]
				b := vote[j]
				wins[[2]string{a, b}]++
			}
		}
	}

	condorcetWinners := []string{}
	for _, c1 := range candidates {
		isWinner := true
		for _, c2 := range candidates {
			if c1 != c2 {
				if wins[[2]string{c1, c2}] <= k/2 {
					isWinner = false
					break
				}
			}
		}
		if isWinner {
			condorcetWinners = append(condorcetWinners, c1)
		}
	}

	if len(condorcetWinners) == 1 {
		return condorcetWinners[0]
	} else if len(condorcetWinners) == 0 {
		return "НЕ ОПРЕДЕЛЁН (парадокс Кондорсе)"
	} else {
		return "НЕ ОПРЕДЕЛЁН (ничья)"
	}
}

func main() {
	var k int
	fmt.Print("Введите количество избирателей: ")
	fmt.Scan(&k)

	var n int
	fmt.Print("Введите количество кандидатов: ")
	fmt.Scan(&n)

	candidates := make([]string, n)
	fmt.Print("Введите имена кандидатов: ")
	for i := 0; i < n; i++ {
		fmt.Scan(&candidates[i])
	}

	votes := make([][]string, k)
	fmt.Println("\nВведите голоса (ранжирование от 1-го места к последнему):")
	for i := 0; i < k; i++ {
		fmt.Printf("Избиратель %d: ", i+1)
		votes[i] = make([]string, n)
		for j := 0; j < n; j++ {
			fmt.Scan(&votes[i][j])
		}
	}

	bordaWin := bordaWinner(votes, candidates)
	fmt.Println("По Борду:", bordaWin)

	condorcetWin := condorcetWinner(votes, candidates)
	fmt.Println("По Кондорсе:", condorcetWin)

	if bordaWin == condorcetWin {
		fmt.Println("\nСОВПАДАЮТ!")
	} else {
		fmt.Println("\nРАЗНЫЕ!")
		fmt.Println("Это нормально для теории голосований")
	}
}
