#ifndef EUCLIDEAN_H
#define EUCLIDEAN_H

struct EuclideanResult {
    long long gcd;
    long long u;
    long long v;
};

long long gcd(long long a, long long b);
EuclideanResult extendedGCD(long long a, long long b);
long long modInverse(long long c, long long m);
bool verifyInverse(long long c, long long d, long long m);

#endif
