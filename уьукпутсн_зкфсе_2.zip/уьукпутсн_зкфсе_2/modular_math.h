#ifndef MODULAR_MATH_H
#define MODULAR_MATH_H

#include <vector>

bool isPrime(long long n);
bool checkFermatTheorem(long long a, long long p);
std::vector<int> toBinary(long long n);
long long modPowFermat(long long a, long long x, long long p);
long long modPowBinary(long long a, long long x, long long p);

#endif
