#include "modular_math.h"
#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

bool isPrime(long long n) {
    if (n <= 1) return false;
    if (n <= 3) return true;
    if (n % 2 == 0 || n % 3 == 0) return false;
    for (long long i = 5; i * i <= n; i += 6) {
        if (n % i == 0 || n % (i + 2) == 0) return false;
    }
    return true;
}

bool checkFermatTheorem(long long a, long long p) {
    cout << "\n--- proverka usloviy teoremy Ferma ---" << endl;
    cout << "parametry: a = " << a << ", p = " << p << endl;

    if (!isPrime(p)) {
        cout << "oshibka: p = " << p << " ne yavlyaetsya prostym chislom" << endl;
        return false;
    }
    cout << "p = " << p << " - prostoe chislo" << endl;

    if (a % p == 0) {
        cout << "oshibka: a = " << a << " delitsya na p = " << p << endl;
        return false;
    }
    cout << "a ne delitsya na p" << endl;

    long long fermat_check = modPowBinary(a, p - 1, p);
    cout << "proverka teoremy Ferma: ";
    cout << a << "^(" << p-1 << ") mod " << p << " = " << fermat_check << endl;

    if (fermat_check == 1) {
        cout << "malaya teorema Ferma vypolnyaetsya" << endl;
        return true;
    } else {
        cout << "malaya teorema Ferma ne vypolnyaetsya" << endl;
        return false;
    }
}

vector<int> toBinary(long long n) {
    vector<int> binary;
    if (n == 0) {
        binary.push_back(0);
        return binary;
    }
    while (n > 0) {
        binary.push_back(n % 2);
        n = n / 2;
    }
    reverse(binary.begin(), binary.end());
    return binary;
}

long long modPowFermat(long long a, long long x, long long p) {
    cout << "\n--- metod 1: vychislenie cherez teoremu Ferma ---" << endl;
    cout << "vychislyaem " << a << "^" << x << " mod " << p << endl;

    if (!checkFermatTheorem(a, p)) {
        cout << "nevozmozhno primenit teoremu Ferma" << endl;
        return -1;
    }

    long long reduced_x = x % (p - 1);
    cout << "redukciya stepeni: " << x << " mod " << (p-1) << " = " << reduced_x << endl;
    cout << "teper vychislyaem: " << a << "^" << reduced_x << " mod " << p << endl;

    return modPowBinary(a, reduced_x, p);
}

long long modPowBinary(long long a, long long x, long long p) {
    cout << "\n--- metod 2: binarniy algoritm vozvedeniya v stepen ---" << endl;
    cout << "vychislyaem " << a << "^" << x << " mod " << p << endl;

    if (x == 0) {
        cout << "stepen ravna 0, resultat = 1" << endl;
        return 1 % p;
    }

    vector<int> binary = toBinary(x);

    cout << "dvoichnoe predstavlenie stepeni " << x << ": ";
    for (int i = 0; i < binary.size(); i++) {
        cout << binary[i];
    }
    cout << endl;

    long long result = 1;
    long long base = a % p;

    cout << "nachalnoe sostoyanie: result = " << result << ", base = " << base << endl;
    cout << "poshagovye vychisleniya:" << endl;

    for (int i = binary.size() - 1; i >= 0; i--) {
        int step = binary.size() - i;
        cout << "shag " << step << ", bit " << binary[i] << ": ";

        if (binary[i] == 1) {
            long long old_result = result;
            result = (result * base) % p;
            cout << "result = " << old_result << " * " << base << " mod " << p << " = " << result;
        } else {
            cout << "result ne menyaetsya = " << result;
        }
        cout << endl;

        if (i > 0) {
            long long old_base = base;
            base = (base * base) % p;
            cout << "       base = " << old_base << "^2 mod " << p << " = " << base << endl;
        }
    }

    cout << "resultat: " << a << "^" << x << " mod " << p << " = " << result << endl;
    return result;
}
