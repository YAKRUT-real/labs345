#ifndef HUGHES_CIPHER_H
#define HUGHES_CIPHER_H

#include <string>
#include <vector>

struct HughesKeys {
    long long p;
    long long e;
    long long d;
};

HughesKeys generateKeys(long long p, long long e);
long long encryptChar(char c, const HughesKeys& keys);
char decryptChar(long long encrypted, const HughesKeys& keys);
std::vector<long long> encryptString(const std::string& text, const HughesKeys& keys);
std::string decryptString(const std::vector<long long>& encrypted, const HughesKeys& keys);
bool encryptFile(const std::string& inputFile, const std::string& outputFile, const HughesKeys& keys);
bool decryptFile(const std::string& inputFile, const std::string& outputFile, const HughesKeys& keys);

#endif
