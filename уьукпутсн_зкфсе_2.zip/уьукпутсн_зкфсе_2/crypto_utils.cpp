#include "crypto_utils.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <limits>

using namespace std;

string readFile(const string& filename) {
    ifstream file(filename);
    if (!file.is_open()) {
        return "";
    }
    stringstream buffer;
    buffer << file.rdbuf();
    return buffer.str();
}

bool writeFile(const string& filename, const string& content) {
    ofstream file(filename);
    if (!file.is_open()) {
        return false;
    }
    file << content;
    file.close();
    return true;
}

void printSeparator(const string& title) {
    cout << "\n" << string(60, '=') << endl;
    if (title != "") {
        cout << "  " << title << endl;
        cout << string(60, '=') << endl;
    }
}

void printHeader(const string& title) {
    cout << "\n" << string(60, '=') << endl;
    cout << "  " << title << endl;
    cout << string(60, '=') << endl;
}

void clearScreen() {
    system("clear");
}

void waitForKey() {
    cout << "\nnazhmite Enter dlya prodolzheniya...";
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
    cin.get();
}
