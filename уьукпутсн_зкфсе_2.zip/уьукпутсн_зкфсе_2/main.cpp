#include <iostream>
#include <string>
#include <vector>
#include <limits>
#include "modular_math.h"
#include "euclidean.h"
#include "hughes_cipher.h"
#include "crypto_utils.h"

using namespace std;

void task1() {
    printHeader("zadanie 1: a^x mod p");
    cout << "sravnenie po modulyu prostogo chisla" << endl;
    cout << "metody: teorema Ferma i binarnoe razlozhenie stepeni\n" << endl;

    long long a, x, p;
    cout << "vvedite osnovanie a: ";
    cin >> a;
    cout << "vvedite stepen x: ";
    cin >> x;
    cout << "vvedite modul p: ";
    cin >> p;
    cin.ignore(numeric_limits<streamsize>::max(), '\n');

    if (!isPrime(p)) {
        cout << "\nvnimanie: p = " << p << " ne yavlyaetsya prostym chislom" << endl;
        cout << "teorema Ferma mozhet ne rabotat" << endl;
        cout << "prodolzhaem vychisleniya tolko binarnym metodom\n" << endl;
    }

    cout << "\n" << string(60, '=') << endl;
    long long result_fermat = modPowFermat(a, x, p);

    cout << "\n" << string(60, '=') << endl;
    long long result_binary = modPowBinary(a, x, p);

    cout << "\n" << string(60, '=') << endl;
    cout << "itogovoe sravnenie metodov:" << endl;
    cout << string(60, '-') << endl;
    cout << "rezultat (teorema Ferma): " << result_fermat << endl;
    cout << "rezultat (binarniy metod): " << result_binary << endl;

    if (result_fermat == result_binary) {
        cout << "rezultaty sovpadayut" << endl;
    } else {
        cout << "rezultaty razlichayutsya" << endl;
    }
}

void task2() {
    printHeader("zadanie 2: rasshirenniy algoritm Evklida");
    cout << "nahozhdenie c*d mod m = 1 cherez u i v\n" << endl;

    long long c, m;
    cout << "vvedite c: ";
    cin >> c;
    cout << "vvedite m: ";
    cin >> m;
    cin.ignore(numeric_limits<streamsize>::max(), '\n');

    EuclideanResult result = extendedGCD(c, m);

    if (result.gcd == 1) {
        long long d = result.u;
        if (d < 0) d = d + m;

        cout << "\n--- rezultat dlya c*d mod m = 1 ---" << endl;
        cout << c << " * " << d << " mod " << m << " = " << (c * d) % m << endl;
        cout << "d = " << d << endl;
    } else {
        cout << "\nchisla ne vzaimno prostye, obratniy element ne suschestvuet" << endl;
    }
}

void task3() {
    printHeader("zadanie 3: obratniy element c^-1 mod m");
    cout << "nahozhdenie d = c^-1 mod m\n" << endl;

    long long c, m;
    cout << "vvedite c: ";
    cin >> c;
    cout << "vvedite m: ";
    cin >> m;
    cin.ignore(numeric_limits<streamsize>::max(), '\n');

    long long inverse = modInverse(c, m);

    if (inverse != -1) {
        cout << "\n--- otvet ---" << endl;
        cout << c << "^-1 mod " << m << " = " << inverse << endl;
        verifyInverse(c, inverse, m);
    }
}

void task4() {
    printHeader("zadanie 4: shifr Huza");

    int choice;
    cout << "vyberite rezhim raboty:" << endl;
    cout << "1. shifrovanie/deshifrovanie stroki" << endl;
    cout << "2. shifrovanie fayla" << endl;
    cout << "3. deshifrovanie fayla" << endl;
    cout << "vash vybor: ";
    cin >> choice;
    cin.ignore(numeric_limits<streamsize>::max(), '\n');

    long long p, e;
    cout << "\nvvedite prostoe chislo p: ";
    cin >> p;
    cout << "vvedite klyuch shifrovaniya e: ";
    cin >> e;
    cin.ignore(numeric_limits<streamsize>::max(), '\n');

    if (!isPrime(p)) {
        cout << "oshibka: p dolzhno byt prostym chislom" << endl;
        return;
    }

    HughesKeys keys = generateKeys(p, e);

    if (keys.d == -1) {
        cout << "oshibka generacii kluchey" << endl;
        return;
    }

    if (choice == 1) {
        string text;
        cout << "\nvvedite tekst dlya shifrovaniya: ";
        getline(cin, text);

        vector<long long> encrypted = encryptString(text, keys);
        string decrypted = decryptString(encrypted, keys);

        if (text == decrypted) {
            cout << "\nshifrovanie/deshifrovanie uspeshno" << endl;
        } else {
            cout << "\noshibka: ishodniy i deshifrovanniy tekst ne sovpadayut" << endl;
        }
    }
    else if (choice == 2) {
        string inputFile, outputFile;
        cout << "vvedite imya vhodnogo fayla: ";
        getline(cin, inputFile);
        cout << "vvedite imya vyhodnogo fayla: ";
        getline(cin, outputFile);

        encryptFile(inputFile, outputFile, keys);
    }
    else if (choice == 3) {
        string inputFile, outputFile;
        cout << "vvedite imya zashifrovannogo fayla: ";
        getline(cin, inputFile);
        cout << "vvedite imya fayla dlya sohraneniya rezultata: ";
        getline(cin, outputFile);

        decryptFile(inputFile, outputFile, keys);
    }
    else {
        cout << "neverniy vybor" << endl;
    }
}

int main() {
    setlocale(LC_ALL, "Russian");

    int choice;

    do {
        clearScreen();
        cout << "\n" << string(60, '-') << endl;
        cout << "glavnoe menu:" << endl;
        cout << string(60, '-') << endl;
        cout << "1. zadanie 1 - a^x mod p" << endl;
        cout << "2. zadanie 2 - rasshirenniy algoritm Evklida" << endl;
        cout << "3. zadanie 3 - obratniy element c^-1 mod m" << endl;
        cout << "4. zadanie 4 - shifr Huza" << endl;
        cout << "0. vyhod" << endl;
        cout << string(60, '-') << endl;
        cout << "vash vybor: ";

        cin >> choice;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        if (choice == 1) task1();
        else if (choice == 2) task2();
        else if (choice == 3) task3();
        else if (choice == 4) task4();
        else {
            cout << "neverniy vybor" << endl;
            waitForKey();
        }

        if (choice != 0) waitForKey();

    } while (choice != 0);

        return 0;
}
