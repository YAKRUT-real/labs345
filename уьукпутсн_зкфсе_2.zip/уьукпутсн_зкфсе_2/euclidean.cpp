#include "euclidean.h"
#include <iostream>
#include <iomanip>

using namespace std;

long long gcd(long long a, long long b) {
    if (a < 0) a = -a;
    if (b < 0) b = -b;

    cout << "\n--- obychniy algoritm Evklida ---" << endl;
    cout << "vychislyaem NOD(" << a << ", " << b << ")" << endl;

    int step = 1;
    while (b != 0) {
        long long q = a / b;
        long long r = a % b;
        cout << "shag " << step << ": " << a << " = " << b << " * " << q << " + " << r << endl;
        a = b;
        b = r;
        step++;
    }

    cout << "NOD = " << a << endl;
    return a;
}

EuclideanResult extendedGCD(long long a, long long b) {
    cout << "\n--- rasshirenniy algoritm Evklida ---" << endl;
    cout << "nahodim u i v takie, chto " << a << " * u + " << b << " * v = NOD(" << a << ", " << b << ")" << endl;

    cout << "\ntablica vychisleniy:" << endl;
    cout << setw(12) << "ostatok r" << setw(12) << "koef u" << setw(12) << "koef v" << setw(12) << "chastnoe q" << endl;
    cout << string(48, '-') << endl;

    long long old_r = a, r = b;
    long long old_u = 1, u = 0;
    long long old_v = 0, v = 1;

    cout << setw(12) << old_r << setw(12) << old_u << setw(12) << old_v << setw(12) << "-" << endl;
    cout << setw(12) << r << setw(12) << u << setw(12) << v << setw(12) << "-" << endl;

    while (r != 0) {
        long long q = old_r / r;

        long long temp_r = r;
        r = old_r - q * r;
        old_r = temp_r;

        long long temp_u = u;
        u = old_u - q * u;
        old_u = temp_u;

        long long temp_v = v;
        v = old_v - q * v;
        old_v = temp_v;

        if (r != 0) {
            cout << setw(12) << r << setw(12) << u << setw(12) << v << setw(12) << q << endl;
        } else {
            cout << setw(12) << "0" << setw(12) << "-" << setw(12) << "-" << setw(12) << q << endl;
        }
    }

    cout << string(48, '-') << endl;

    EuclideanResult result;
    result.gcd = old_r;
    result.u = old_u;
    result.v = old_v;

    cout << "\nrezultaty:" << endl;
    cout << "NOD(" << a << ", " << b << ") = " << result.gcd << endl;
    cout << "u = " << result.u << endl;
    cout << "v = " << result.v << endl;

    long long check = a * result.u + b * result.v;
    cout << "proverka: " << a << " * (" << result.u << ") + " << b << " * (" << result.v << ") = " << check << endl;

    if (check == result.gcd) {
        cout << "proverka proidena" << endl;
    } else {
        cout << "oshibka v vychisleniyah" << endl;
    }

    return result;
}

long long modInverse(long long c, long long m) {
    cout << "\n--- nahozhdenie obratnogo elementa ---" << endl;
    cout << "ishem d takoe, chto " << c << " * d = 1 (mod " << m << ")" << endl;

    cout << "\nuproschennaya tablica:" << endl;
    cout << setw(15) << "ostatok r" << setw(15) << "koef t" << setw(15) << "chastnoe q" << endl;
    cout << string(45, '-') << endl;

    long long m_orig = m;
    long long t = 0, newt = 1;
    long long r = m, newr = c;

    cout << setw(15) << r << setw(15) << t << setw(15) << "-" << endl;
    cout << setw(15) << newr << setw(15) << newt << setw(15) << "-" << endl;

    while (newr != 0) {
        long long q = r / newr;

        long long temp_t = newt;
        newt = t - q * newt;
        t = temp_t;

        long long temp_r = newr;
        newr = r - q * newr;
        r = temp_r;

        if (newr != 0) {
            cout << setw(15) << newr << setw(15) << newt << setw(15) << q << endl;
        } else {
            cout << setw(15) << "0" << setw(15) << "-" << setw(15) << q << endl;
        }
    }

    cout << string(45, '-') << endl;

    if (r != 1) {
        cout << "\noshibka: " << c << " i " << m << " ne vzaimno prostye" << endl;
        cout << "NOD(" << c << ", " << m << ") = " << r << endl;
        return -1;
    }

    long long inverse = t;
    if (inverse < 0) {
        inverse = inverse + m_orig;
    }

    cout << "\nobratniy element: " << c << "^-1 mod " << m << " = " << inverse << endl;
    return inverse;
}

bool verifyInverse(long long c, long long d, long long m) {
    long long result = (c * d) % m;
    cout << "proverka: " << c << " * " << d << " mod " << m << " = " << result;
    if (result == 1) {
        cout << " (verno)" << endl;
        return true;
    } else {
        cout << " (oshibka)" << endl;
        return false;
    }
}
