#ifndef CRYPTO_UTILS_H
#define CRYPTO_UTILS_H

#include <string>

std::string readFile(const std::string& filename);
bool writeFile(const std::string& filename, const std::string& content);
void printSeparator(const std::string& title = "");
void printHeader(const std::string& title);
void clearScreen();
void waitForKey();

#endif
