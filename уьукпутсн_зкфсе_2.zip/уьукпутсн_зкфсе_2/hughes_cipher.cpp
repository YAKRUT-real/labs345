#include "hughes_cipher.h"
#include "modular_math.h"
#include "euclidean.h"
#include "crypto_utils.h"
#include <iostream>
#include <fstream>
#include <sstream>

using namespace std;

HughesKeys generateKeys(long long p, long long e) {
    cout << "\n--- generaciya kluchey shifra Huza ---" << endl;

    HughesKeys keys;
    keys.p = p;
    keys.e = e;

    cout << "ishodnye parametry:" << endl;
    cout << "  p = " << p << endl;
    cout << "  e = " << e << endl;

    if (!isPrime(p)) {
        cout << "oshibka: p = " << p << " ne yavlyaetsya prostym chislom" << endl;
        keys.d = -1;
        return keys;
    }

    cout << "\nvychislenie zakrytogo klyucha d = e^-1 mod (p-1):" << endl;
    keys.d = modInverse(e, p - 1);

    if (keys.d == -1) {
        cout << "ne udalos vychislit zakrytiy klyuch" << endl;
        return keys;
    }

    cout << "\nsgenerirovannye klyuchi:" << endl;
    cout << "otkrytiy klyuch: (p = " << keys.p << ", e = " << keys.e << ")" << endl;
    cout << "zakrytiy klyuch: d = " << keys.d << endl;

    long long check = (keys.e * keys.d) % (keys.p - 1);
    cout << "proverka: e * d mod (p-1) = " << keys.e << " * " << keys.d;
    cout << " mod " << (keys.p - 1) << " = " << check;
    if (check == 1) {
        cout << " (verno)" << endl;
    } else {
        cout << " (oshibka)" << endl;
    }

    return keys;
}

long long encryptChar(char c, const HughesKeys& keys) {
    long long m = (long long)c;
    long long encrypted = modPowBinary(m, keys.e, keys.p);
    cout << "  simvol '" << c << "' (kod " << m << ") -> " << encrypted << endl;
    return encrypted;
}

char decryptChar(long long encrypted, const HughesKeys& keys) {
    long long decrypted = modPowBinary(encrypted, keys.d, keys.p);
    char result = (char)decrypted;
    cout << "  chislo " << encrypted << " -> kod " << decrypted << " -> simvol '" << result << "'" << endl;
    return result;
}

vector<long long> encryptString(const string& text, const HughesKeys& keys) {
    cout << "\n--- shifrovanie teksta ---" << endl;
    cout << "ishodniy tekst: \"" << text << "\"" << endl;
    cout << "dlina: " << text.length() << " simvolov" << endl;
    cout << "\nprocess shifrovaniya:" << endl;

    vector<long long> encrypted;
    for (int i = 0; i < text.length(); i++) {
        encrypted.push_back(encryptChar(text[i], keys));
    }

    cout << "\nzashifrovannaya posledovatelnost: ";
    for (int i = 0; i < encrypted.size(); i++) {
        cout << encrypted[i];
        if (i < encrypted.size() - 1) cout << " ";
    }
    cout << endl;

    return encrypted;
}

string decryptString(const vector<long long>& encrypted, const HughesKeys& keys) {
    cout << "\n--- deshifrovanie teksta ---" << endl;
    cout << "zashifrovannaya posledovatelnost: ";
    for (int i = 0; i < encrypted.size(); i++) {
        cout << encrypted[i];
        if (i < encrypted.size() - 1) cout << " ";
    }
    cout << endl;
    cout << "\nprocess deshifrovaniya:" << endl;

    string decrypted = "";
    for (int i = 0; i < encrypted.size(); i++) {
        decrypted = decrypted + decryptChar(encrypted[i], keys);
    }

    cout << "\ndeshifrovanniy tekst (kody): ";
    for (int i = 0; i < decrypted.length(); i++) {
        cout << (int)(unsigned char)decrypted[i];
        if (i < decrypted.length() - 1) cout << " ";
    }
    cout << endl;

    cout << "deshifrovanniy tekst (simvoly): \"";
    for (int i = 0; i < decrypted.length(); i++) {
        unsigned char ch = decrypted[i];
        if (ch >= 32 && ch <= 126) {
            cout << ch;
        } else {
            cout << "[" << (int)ch << "]";
        }
    }
    cout << "\"" << endl;

    return decrypted;
}

bool encryptFile(const string& inputFile, const string& outputFile, const HughesKeys& keys) {
    cout << "\n--- shifrovanie fayla ---" << endl;
    cout << "vhodnoy fayl: " << inputFile << endl;
    cout << "vyhodnoy fayl: " << outputFile << endl;

    string content = readFile(inputFile);
    if (content == "") {
        cout << "oshibka: fayl pust ili ne suschestvuet" << endl;
        return false;
    }

    cout << "prochitano simvolov: " << content.length() << endl;

    vector<long long> encrypted = encryptString(content, keys);

    ofstream outFile(outputFile);
    if (!outFile.is_open()) {
        cout << "oshibka: nevozmozhno sozdat vyhodnoy fayl" << endl;
        return false;
    }

    for (int i = 0; i < encrypted.size(); i++) {
        outFile << encrypted[i];
        if (i < encrypted.size() - 1) outFile << " ";
    }
    outFile.close();

    cout << "\nfayl uspeshno zashifrovan" << endl;
    return true;
}

bool decryptFile(const string& inputFile, const string& outputFile, const HughesKeys& keys) {
    cout << "\n--- deshifrovanie fayla ---" << endl;
    cout << "vhodnoy fayl: " << inputFile << endl;
    cout << "vyhodnoy fayl: " << outputFile << endl;

    ifstream inFile(inputFile);
    if (!inFile.is_open()) {
        cout << "oshibka: nevozmozhno otkryt vhodnoy fayl" << endl;
        return false;
    }

    vector<long long> encrypted;
    long long val;
    while (inFile >> val) {
        encrypted.push_back(val);
    }
    inFile.close();

    cout << "prochitano chisel: " << encrypted.size() << endl;

    string decrypted = decryptString(encrypted, keys);

    if (writeFile(outputFile, decrypted)) {
        cout << "\nfayl uspeshno deshifrovan" << endl;
        return true;
    } else {
        cout << "oshibka: nevozmozhno zapisat vyhodnoy fayl" << endl;
        return false;
    }
}
